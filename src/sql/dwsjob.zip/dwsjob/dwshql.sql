insert overwrite table qfbap_dws.dws_user_visit_month1 partition(dt=${hivevar:date_dt})
select
user_id,
`type`,
cnt,
content,
row_number() over (partition by user_id,type order by cnt) rn,
dw_date
from
(select
user_id,
'cookie_id' `type`,
sum(pv) cnt,
cookie_id content,
dw_date
from
qfbap_dwd.dwd_user_pc_pv
group by user_id,cookie_id,dw_date
union all
select
user_id,
'visit_os' type,
sum(pv) cnt,
visit_os content,
dw_date
from
qfbap_dwd.dwd_user_pc_pv
group by user_id,visit_os,dw_date
union all
select
user_id,
'browser_name' type,
sum(pv) cnt,
browser_name content,
dw_date
from
qfbap_dwd.dwd_user_pc_pv
group by user_id,browser_name,dw_date
union all
select
user_id,
'visit_ip' type,
sum(pv) cnt,
visit_ip content,
dw_date
from
qfbap_dwd.dwd_user_pc_pv
group by user_id,visit_ip,dw_date) t;
