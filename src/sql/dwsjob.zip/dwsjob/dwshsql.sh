#!/bin/bash
args=$1
dt=${hivevar:date_dt}=
if [ ${#args1} == 0 ]
then
 dt=${hivevar:date_dt}=`date -d "1 day ago" "+%Y%m%d"`
else
 dt=${hivevar:date_dt}=$1
fi
echo "load dwd hive"
set hive.variable.substitute=true;
set hive.exec.mode.local.auto=false;
hive -hivevar date_dt=${dt=${hivevar:date_dt}} -f dwshql.sql
